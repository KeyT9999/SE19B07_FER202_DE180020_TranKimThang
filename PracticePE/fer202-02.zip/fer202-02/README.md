1. Cài đặt gói:
   npm install react react-dom react-scripts react-router-dom bootstrap react-bootstrap styled-components react-icons prop-types json-server
   npm install axios

2. Chạy dự án: chạy sever trước tiên

- Chạy sever:
  npx json-server --watch db.json --port 3001
- Chạy fe:
  npm start
