//Bước 8: Tạo trang LoginPage
//LoginPage.jsx là trang đăng nhập sử dụng LoginForm
import React from 'react';
import LoginForm from '../components/LoginForm';
const LoginPage = () => {
    return (
        <LoginForm />
    );
};

export default LoginPage;
